# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Rails3Devise::Application.config.secret_token = '87dfa7f6a6f56865724e152e37a15ded06e28f403c6eb4309b41b253fca9cc2b764530e8d5f8e57792618ac74a6924be656d70dc9adf0aba7d5bee148f53ddcc'
